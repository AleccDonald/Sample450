#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "fd.h"
#include "fd.c"
#include "../devices/shutdown.h"
#include "process.h"
#include "../filesys/filesys.h"
#include "../filesys/file.h"

static void syscall_handler (struct intr_frame *);

// //processes
// static int wait(pid_t);
// static pid_t exec(const char *cmd_line);
// static void exit(int status)

// //related to files
// static bool create(const char, unsigned);
// static bool remove(const char);
// static int open(const char);
// static int filesize(int);
// static int read(int, void, unsigned);
// static int write(int, void, unsigned);
// static void seek(int, unsigned);
// static unsigned tell(int);
// static void close(int);


void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
	int syscall_number = *(int*)f->esp;
	switch (syscall_number) {
		case SYS_HALT: {
			shutdown_power_off();
			break;
		}
		case SYS_EXIT: {
			int code = *((int*) (f->esp+sizeof(syscall_number)));
			thread_current()->exit_code = code;
			thread_exit();
			printf("Thread_exit somehow returned!");
			shutdown_power_off();
			break;
		}
		case SYS_EXEC: {
			char* cmdline = *((char**) (f->esp+sizeof(syscall_number)));
			if (!ptr_is_legal(cmdline)) {
				thread_current()->exit_code = -1;
				thread_exit();
				return;
			}
			tid_t pid = process_execute(cmdline);
			//synchronization start 

		// 	lock_acquire(&thread_current()->exec_lock);

		// 	while(!thread_current()->exec_complete) //must not return until new process has successfully loaded or failed
		// 	{	
	 		//synchronization continue
		// 		lock_release(&thread_current()->exec_complete);//unlock
		// 		thread_yield(); //yield CPU to other threads
		// 		lock_acquire(&thread_current()->exec_lock); //relock to continue waiting
					
		// 	}

		 	//rerelease lock
		//	lock_release(&thread_current()->exec_complete);

			f->eax = pid;
			break;
		}
		case SYS_WAIT: {
			int pid = *((int*) (f->esp+sizeof(syscall_number)));
			int ret = process_wait(pid);
			f->eax = ret;
			break;
		}
		case SYS_CREATE: {
			char* file = *((char**) (f->esp+sizeof(syscall_number)));
			int initial_size = *((int*) (f->esp+sizeof(syscall_number)+sizeof(file)));
			if (!ptr_is_legal(file)) {
				thread_current()->exit_code = -1;
				thread_exit();
				return;
			}
			if (!file) {
				f->eax = 0;
				return;
			}
			int len = strlen(file);
			if (len == 0 || len > 14) {
				f->eax = 0;
				return;
			}
			//lock_acquire(&file_lock);
			bool ret = filesys_create(file, initial_size);
			//lock_release(&file_lock);
			f->eax = ret;
			break;
		}
		case SYS_REMOVE: {
			char* file = *((char**) (f->esp+sizeof(syscall_number)));
			if (!file) {
				f->eax = 0;
				return;
			}
			if (!ptr_is_legal(file)) {
				thread_current()->exit_code = -1;
				thread_exit();
				return;
			}
			int len = strlen(file);
			if (len == 0 || len > 14) {
				f->eax = 0;
				return;
			}
			//lock_acquire(&file_lock);
			bool ret = filesys_remove(file);
			//lock_release(&file_lock);
			f->eax = ret;
			break;
		}
		case SYS_OPEN: {
			char* file = *((char**) (f->esp+sizeof(syscall_number)));
			if (!file) {
				// printf("Null file pointer\n");
				f->eax = -1;
				return;
			}
			if (!ptr_is_legal(file)) {
				// printf("Bad pointer to filename\n");
				thread_current()->exit_code = -1;
				thread_exit();
				return;
			}
			int len = strlen(file);
			if (len == 0 || len > 14) {
				// printf("Bad filename\n");
				f->eax = -1;
				return;
			}
			// filesys_create(file, 0);
			//lock_acquire(&file_lock);
			struct file* file_handle = filesys_open(file);
			if (!file_handle) {
				// printf("No file\n");
				f->eax = -1;
				return;
			}
			int file_descriptor = fd_alloc(thread_tid(), file_handle);
			//lock_release(&file_lock);
			f->eax = file_descriptor;
			break;
		}
		case SYS_FILESIZE: {
			int file_descriptor = *((int*) (f->esp+sizeof(syscall_number)));
			struct file* file_handle = fd_get(thread_tid(), file_descriptor);
			//lock_acquire(&file_lock);
			if (!file_handle) {
				f->eax = 0;
				return;
			}
			unsigned len = file_length(file_handle);
			//lock_release(&file_lock);
			f->eax = len;
			break;
		}
		case SYS_READ: {
			int file_descriptor = *((int*) (f->esp+sizeof(syscall_number)));
			void* buffer = *((void**) (f->esp+sizeof(syscall_number)+sizeof(file_descriptor)));
			unsigned size = *((unsigned*) (f->esp+sizeof(syscall_number)+sizeof(file_descriptor)+sizeof(buffer)));
			if (!size) {
				f->eax = 0;
				return;
			}
			if (!ptr_is_legal(buffer) || !ptr_is_legal(buffer+size)) {
				thread_current()->exit_code = -1;
				thread_exit();
				return;
			}
			struct file* file_handle = fd_get(thread_tid(), file_descriptor);
			if (!file_handle) {
				f->eax = -1;
				return;
			}
			unsigned ret = file_read(file_handle, buffer, size);
			f->eax = ret;
			break;
		}
		case SYS_WRITE: {
			int file_descriptor = *((int*) (f->esp+sizeof(syscall_number)));
			void* buffer = *((void**) (f->esp+sizeof(syscall_number)+sizeof(file_descriptor)));
			unsigned size = *((unsigned*) (f->esp+sizeof(syscall_number)+sizeof(file_descriptor)+sizeof(buffer)));
			if (!size) {
				f->eax = 0;
				return;
			}
			if (!ptr_is_legal(buffer) || !ptr_is_legal(buffer+size)) {
				thread_current()->exit_code = -1;
				thread_exit();
				return;
			}
			if (file_descriptor == 1) {
				void* end = buffer + size;
				for (;buffer<end;++buffer) {
					printf("%c", *(char*)buffer);
				}
			} else {
				struct file* file_handle = fd_get(thread_tid(), file_descriptor);
				if (!file_handle) {
					f->eax = -1;
					return;
				}
				unsigned ret = file_write(file_handle, buffer, size);
				f->eax = ret;
			}
			break;
		}
		case SYS_SEEK: {
			int file_descriptor = *((int*) (f->esp+sizeof(syscall_number)));
			unsigned position = *((unsigned*) (f->esp+sizeof(syscall_number)+sizeof(file_descriptor)));
			struct file* file_handle = fd_get(thread_tid(), file_descriptor);
			//lock_acquire(&file_lock);
			if (!file_handle) {
				return;
			}
			file_seek(file_handle, position);
			//lock_release(&file_lock);
			break;
		}
		case SYS_TELL: {
			int file_descriptor = *((int*) (f->esp+sizeof(syscall_number)));
			struct file* file_handle = fd_get(thread_tid(), file_descriptor);
			//lock_acquire(&file_lock);
			if (!file_handle) {
				f->eax = -1;
				return;
			}
			unsigned ret = file_tell(file_handle);
			//lock_release(&file_lock);
			f->eax = ret;
			break;
		}
		case SYS_CLOSE:{
			int file_descriptor = *((int*) (f->esp+sizeof(syscall_number)));
			struct file* file_handle = fd_get(thread_tid(), file_descriptor);
			//lock_acquire(&file_lock);
			if (!file_handle) {
				return;
			}
			fd_del(thread_tid(), file_descriptor);
			//lock_release(&file_lock);
			break;
		}
		default: {
			thread_current()->exit_code = -1;
			thread_exit();
			return;
		}
	}
}

