#include "fd.h"
#include "../devices/shutdown.h"
#include "../filesys/filesys.h"
#include "../filesys/file.h"

int fd_alloc(tid_t owner, struct file* for_file) {
    int index = 3;
    for (; index < FD_LIMIT && *(char*)(&FD_TABLE[index]); ++index);
    if (index == FD_LIMIT) {
        printf("Ran out of file descriptors!!!");
        shutdown_power_off();
    }
    FD_TABLE[index].allocated = 1;
    FD_TABLE[index].owner = owner;
    FD_TABLE[index].for_file = for_file;

    return index;
}

struct file* fd_get(tid_t owner, int fd) {
    if (fd < 0 || fd >= FD_LIMIT) {
        return 0;
    }
    struct fd it = FD_TABLE[fd];
    if (!it.allocated || (owner != -1 && it.owner != owner)) {
        return 0;
    }
    return it.for_file;
}

void fd_del(tid_t owner, int fd) {
    if (fd < 0 || fd >= FD_LIMIT) {
        return;
    }
    struct fd* it = &FD_TABLE[fd];
    if ((owner != -1 && it->owner != owner)) {
        return;
    }
    if (it->allocated) {
        it->allocated = 0;
        file_close(it->for_file);
    }
}
