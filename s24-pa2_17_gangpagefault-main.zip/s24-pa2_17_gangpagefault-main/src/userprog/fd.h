#ifndef FD_LIMIT
#define FD_LIMIT 128

struct fd {
    char allocated;
    tid_t owner;
    struct file* for_file;
};

static struct fd FD_TABLE[FD_LIMIT];

int fd_alloc(tid_t owner, struct file* for_file);

struct file* fd_get(tid_t owner, int fd);

void fd_del(tid_t owner, int fd);
#endif